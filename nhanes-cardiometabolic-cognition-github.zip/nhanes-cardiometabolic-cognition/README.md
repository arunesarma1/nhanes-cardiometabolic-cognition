# Cardiometabolic Risk-Factor Burden and Cognitive Performance Among Older U.S. Adults

**Exploratory cross-sectional analysis | NHANES 2011–2014 | Python + R**

## Overview

This independent computational epidemiology project examines the association between cumulative cardiometabolic risk-factor burden and cognitive performance in U.S. adults aged 60 years and older. It emphasizes survey-weighted descriptive and regression analysis, covariate adjustment, model specification, and missing-data considerations.

The full abstract, Methods, Results, and methodological reflection are available in the [research report](docs/research_report.pdf).

## Research question

Is a higher number of cardiometabolic risk factors associated with lower Digit Symbol Substitution Test (DSST) performance among older U.S. adults, after adjustment for demographic and socioeconomic characteristics?

## Data and analysis

- **Source:** National Health and Nutrition Examination Survey (NHANES), 2011–2012 and 2013–2014 cycles.
- **Population:** MEC-examined U.S. adults aged ≥60 years; 3,472 eligible, 2,804 in the primary complete-case analysis.
- **Exposure:** Sum of hypertension, diabetes, obesity, and dyslipidemia classifications (0–4).
- **Outcome:** DSST score (higher scores indicate better cognitive performance).
- **Primary model:** Survey-weighted linear regression adjusting for age, sex, race/ethnicity, and education.
- **Additional analyses:** Income adjustment in the income-complete sample (n = 2,577), categorical burden specification, quadratic age/income terms, and comparisons of included versus excluded participants.
- **Survey design:** Four-year MEC weights (`WTMEC2YR / 2`), strata (`SDMVSTRA`), and PSUs (`SDMVPSU`) using R's `survey` package.

## Results

In the primary demographic-adjusted model, each additional cardiometabolic risk factor was associated with a **1.18-point lower DSST score** (β = −1.18; 95% CI: −1.94 to −0.41; n = 2,804). In the income-complete sample, further adjustment for family poverty-income ratio yielded β = −1.02 (95% CI: −1.76 to −0.28; n = 2,577).

### Figure 1. Survey-weighted cognitive performance by burden

![Survey-weighted mean DSST score by cardiometabolic risk-factor burden, with 95% confidence intervals](outputs/figures/figure1_dsst_by_burden.png)

*Descriptive estimates; not adjusted for demographic or socioeconomic covariates.*

### Figure 2. Regression estimates across model specifications

![Regression coefficient and 95% confidence interval for burden across four model specifications](outputs/figures/figure2_regression_coefficients.png)

*Coefficients represent the estimated DSST-score difference per additional risk factor. Income-complete models use n = 2,577; other models use n = 2,804.*

Detailed descriptive results are in [Table 1](outputs/tables/table1.csv), and primary regression estimates in [Table 2](outputs/tables/table2.csv).

## Repository contents

```text
.
├── README.md
├── docs/
│   └── research_report.pdf
├── src/
│   ├── 01_prepare_data.py
│   ├── 02_survey_analysis.R
│   └── 03_generate_outputs.R
├── data/
│   └── processed/
│       └── nhanes_2011_2014_processed.csv
├── outputs/
│   ├── analysis/
│   │   ├── burden_model_results.csv
│   │   └── dsst_by_burden.csv
│   ├── tables/
│   │   ├── table1.csv
│   │   └── table2.csv
│   └── figures/
│       ├── figure1_dsst_by_burden.png
│       └── figure2_regression_coefficients.png
├── requirements.txt
└── .gitignore
```

## Reproducing the analysis

**From the included processed dataset** (no raw download required):

1. Install R packages `survey` and `ggplot2`.
2. From the repository root, run:

```bash
Rscript src/02_survey_analysis.R
Rscript src/03_generate_outputs.R
```

The first script generates `outputs/analysis/` results; the second sources the first script and generates tables and figures. Running the second script alone therefore also reruns the analysis.

**From original NHANES files:** Install Python dependencies using `pip install -r requirements.txt`. Download the public NHANES SAS transport (`.XPT`) files for both cycles from the [CDC NHANES data portal](https://wwwn.cdc.gov/nchs/nhanes/). Place the `DEMO`, `CFQ`, `BPX`, `BPQ`, `DIQ`, `BMX`, `TCHOL`, `HDL`, and `GHB` files in `data/raw/2011-2012/` (suffix `_G`) and `data/raw/2013-2014/` (suffix `_H`), respectively. Then run:

```bash
python src/01_prepare_data.py
Rscript src/03_generate_outputs.R
```

The preprocessing script recreates `data/processed/nhanes_2011_2014_processed.csv`. The raw NHANES XPT files are not included in this repository.

## Interpretation and limitations

These results describe associations and **do not establish causality**. The analysis is cross-sectional, the equally weighted burden score combines heterogeneous conditions, and complete-case selection may introduce bias. Residual confounding is also possible. DSST is a measure of cognitive performance, not a clinical diagnosis of dementia.

## Data source

National Center for Health Statistics, Centers for Disease Control and Prevention. [NHANES 2011–2014 public-use data and documentation](https://wwwn.cdc.gov/nchs/nhanes/).
